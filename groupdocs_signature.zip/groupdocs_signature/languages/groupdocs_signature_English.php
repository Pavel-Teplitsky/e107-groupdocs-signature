<?php
define("GDSIGLAN_01", "Lets you sign document from your web page using the GroupDocs Signature (no Flash or PDF browser plug-ins required).");
define("GDSIGLAN_02", "Settings");
define("GDSIGLAN_03", "Installation Successful...");
define("GDSIGLAN_04", "Upgrade successful...");
define("GDSIGLAN_05", "Save Changes");
define("GDSIGLAN_06", "Changes were saved successfully.");
define("GDSIGLAN_07", "Error: please fill all inputs!");
?>