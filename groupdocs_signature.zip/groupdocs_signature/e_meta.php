<?php
    echo '<script type="text/javascript" src="'.e_PLUGIN.'groupdocs_signature/js/jquery-1.9.1.min.js"></script>';
    echo '<script type="text/javascript" src="'.e_PLUGIN.'groupdocs_signature/js/grpdocs-dialog.js"></script>';
    echo '<link type="text/css" rel="stylesheet" href="'.e_PLUGIN.'groupdocs_signature/css/grpdocs-dialog.css"/>';
?>